# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '264296d00569d39b7bb55d049ff5b108a65507adaaaf8bff5613c8aa5725aafd99268572e4179ce566bf493d5318bb429709f6da0a43a41c6334f473d1b7a631'